import 'jsr:@supabase/functions-js/edge-runtime.d.ts';
import { createClient } from '@supabase/supabase-js';
import { create } from 'https://deno.land/x/djwt@v2.9/mod.ts';
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const QR_SECRET = Deno.env.get('QR_SECRET')!;
const QR_EXPIRY_MS = 15 * 60 * 1000;

// --- 🛡️ CONFIGURATION CORS DYNAMIQUE ---
const ALLOWED_ORIGINS = [
  "https://myfidelity.ca",
  "https://www.myfidelity.ca"
  ];

const getCorsHeaders = (origin: string | null) => {
  const headerOrigin = origin && ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': headerOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json',
  };
};

let cachedKey: CryptoKey | null = null;
async function getSignKey() {
  if (cachedKey) return cachedKey;
  cachedKey = await crypto.subtle.importKey('raw', new TextEncoder().encode(QR_SECRET), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return cachedKey;
}

async function generateSignature(id: string, userId: string, expAt: string) {
  const exp = Math.floor(new Date(expAt).getTime() / 1000);
  const key = await getSignKey();
  return await create({ alg: 'HS256', typ: 'JWT' }, { transaction_id: id, user_id: userId, exp }, key);
}

// --- 🛡️ RATE LIMITING UPSTASH (15 req/min par user) ---
const redis = new Redis({
  url: Deno.env.get('UPSTASH_REDIS_REST_URL')!,
  token: Deno.env.get('UPSTASH_REDIS_REST_TOKEN')!,
});

const ratelimit = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(15, '60 s'),
  prefix: 'rl:get_transaction',
});

Deno.serve(async (req) => {
  const origin = req.headers.get("Origin");
  const corsHeaders = getCorsHeaders(origin);

  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const authHeader = req.headers.get('Authorization');
    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
    
    const { data: { user }, error: authError } = await supabase.auth.getUser(authHeader?.replace('Bearer ', '') || '');
    if (authError || !user) return new Response(JSON.stringify({ error: '401' }), { status: 401, headers: corsHeaders });

    // 🛡️ RATE LIMITING (15 req/min par user)
    const { success: rlOk } = await ratelimit.limit(user.id);
    if (!rlOk) {
      return new Response(JSON.stringify({ error: 'Rate limit exceeded' }), { status: 429, headers: corsHeaders });
    }

    const { data: pendingData, error: rpcError } = await supabase
      .schema('postgre_rpc')
      .rpc('rpc_pending_transaction', { p_user_id: user.id });

    if (rpcError) throw new Error(`Erreur SQL : ${rpcError.message}`);
    const pending = pendingData?.[0];

    if (!pending) {
      return new Response(JSON.stringify({ qr: null, articles: [], recompenses: [] }), { status: 200, headers: corsHeaders });
    }

    const items = Array.isArray(pending.items) ? pending.items : [];
    const usedOffers = Array.isArray(pending.used_offers) ? pending.used_offers : [];

    const ecoGesteItems = items.filter((i: any) => i.type === 'ecogeste' || i.type === 'article' || !i.type);
    const rewards = [
      ...items.filter((i: any) => i.type === 'offer'),
      ...usedOffers.map((id: string) => ({ id, qty: 1 }))
    ];

    const fetchImgs = async (list: any[], table: string, col: string) => {
      if (!list.length) return [];
      const ids = list.map(l => l.id || l.name || l.title).filter(Boolean);
      const { data } = await supabase.schema('private').from(table).select(`${col}, image`).in(col, ids);
      const map = Object.fromEntries(data?.map((d: any) => [d[col], d.image]) || []);
      return list.map(l => {
        const key = l.id || l.name || l.title;
        return { id: key, image: map[key] || null, quantite: l.qty || 1 };
      });
    };

    const [articlesData, recompensesData] = await Promise.all([
      fetchImgs(ecoGesteItems, 'articles', 'name'),
      fetchImgs(rewards, 'offers', 'title')
    ]);

    const expiresAt = new Date(Date.now() + QR_EXPIRY_MS).toISOString();
    const qr = await generateSignature(pending.id, user.id, expiresAt);

    return new Response(
      JSON.stringify({ qr, articles: articlesData, recompenses: recompensesData, expires_at: expiresAt }),
      { status: 200, headers: corsHeaders }
    );

  } catch (err: any) {
    return new Response(JSON.stringify({ error: 'Server Error', details: err.message }), { 
      status: 500, 
      headers: getCorsHeaders(req.headers.get("Origin")) 
    });
  }
});