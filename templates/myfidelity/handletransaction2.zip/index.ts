import 'jsr:@supabase/functions-js/edge-runtime.d.ts';
import { createClient } from '@supabase/supabase-js';
import { create } from 'https://deno.land/x/djwt@v2.9/mod.ts';
import { z } from 'https://deno.land/x/zod@v3.22.4/mod.ts';
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_ROLE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const QR_SECRET = Deno.env.get('QR_SECRET')!;
const TRANSACTION_EXPIRY_MS = 15 * 60 * 1000;

// --- 🛡️ CONFIGURATION CORS STRICTE ---
const ALLOWED_ORIGINS = [
  "https://myfidelity.ca",
  "https://www.myfidelity.ca"
];

const getCorsHeaders = (origin: string | null) => {
  const headerOrigin = origin && ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  
  return {
    'Access-Control-Allow-Origin': headerOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
  };
};

// 🛡️ SCHEMA DE VALIDATION
const TransactionSchema = z.object({
  items: z.array(
    z.object({
      id: z.string().trim().min(1).max(150).regex(/^[a-zA-Z0-9\u00C0-\u00FF\s\-\_\.\(\)\%\,\'\&\/]+$/),
      qty: z.number().int().min(1).max(3)
    }).strict()
  ).min(1).max(10)
}).strict();

// Cache Crypto
let cachedKey: CryptoKey | null = null;
async function getSignKey() {
  if (cachedKey) return cachedKey;
  cachedKey = await crypto.subtle.importKey('raw', new TextEncoder().encode(QR_SECRET), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return cachedKey;
}

async function generateSignature(id: string, userId: string, expAt: string) {
  const exp = Math.floor(new Date(expAt).getTime() / 1000);
  const key = await getSignKey();
  return await create({ alg: 'HS256', typ: 'JWT' }, { transaction_id: id, user_id: userId, exp }, key);
}

// --- 🛡️ RATE LIMITING UPSTASH (20 req/min par user) ---
const redis = new Redis({
  url: Deno.env.get('UPSTASH_REDIS_REST_URL')!,
  token: Deno.env.get('UPSTASH_REDIS_REST_TOKEN')!,
});

const ratelimit = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(20, '60 s'),
  prefix: 'rl:handletransaction2',
});

// -------------------- Handler Principal --------------------
Deno.serve(async (req) => {
  const origin = req.headers.get("Origin");
  const corsHeaders = getCorsHeaders(origin);

  // Gestion du Preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    console.log("--- \ud83d\ude80 D\u00c9MARRAGE TRANSACTION S\u00c9CURIS\u00c9E ---");

    // 1. AUTHENTIFICATION JWT
    const authHeader = req.headers.get('Authorization');
    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);
    const { data: { user }, error: authError } = await supabase.auth.getUser(authHeader?.replace('Bearer ', '') || '');
    
    if (authError || !user) {
      return new Response(JSON.stringify({ error: '401' }), { status: 401, headers: corsHeaders });
    }

    // 🛡️ RATE LIMITING (20 req/min par user)
    const { success: rlOk } = await ratelimit.limit(user.id);
    if (!rlOk) {
      console.log(`\u26d4 [RATE LIMIT] User ${user.email} bloque`);
      return new Response(JSON.stringify({ error: 'Rate limit exceeded' }), { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // 2. \ud83d\udee1\ufe0f V\u00c9RIFICATION DU R\u00d4LE ET DU SOLDE
    const { data: userData, error: userError } = await supabase
      .schema('private')
      .from('users')
      .select('points, role')
      .eq('id', user.id)
      .single();

    if (userError || !userData) throw new Error("Profil utilisateur introuvable");

    const rolesBloques = ['caissier'];
    if (rolesBloques.includes(userData.role)) {
      console.log(`\u274c [BLOCKED] R\u00f4le non autoris\u00e9 : ${userData.role}`);
      return new Response(JSON.stringify({ 
        error: "Acces refuse", 
        message: "Les caissiers ne peuvent pas generer de transactions depuis l'application mobile." 
      }), { status: 403, headers: corsHeaders });
    }

    const soldeInitial = userData.points || 0;

    // 3. CHECK SI TRANSACTION D\u00c9J\u00c0 EN ATTENTE
    const { data: existing } = await supabase.schema('postgre_rpc').rpc('rpc_pending_transaction', { p_user_id: user.id });
    if (existing?.[0]) {
      console.log(`\u267b\ufe0f [RE-USE] Transaction pendante trouvee (ID: ${existing[0].id})`);
      const sig = await generateSignature(existing[0].id, user.id, new Date(Date.now() + TRANSACTION_EXPIRY_MS).toISOString());
      return new Response(JSON.stringify({ qr: sig }), { status: 200, headers: corsHeaders });
    }

    // 4. LECTURE ET VALIDATION DU BODY
    const body = await req.json().catch(() => ({}));
    const validation = TransactionSchema.safeParse(body);
    if (!validation.success) {
      return new Response(JSON.stringify({ error: "Format invalide", details: validation.error.format() }), { status: 400, headers: corsHeaders });
    }

    // 5. CALCUL S\u00c9PAR\u00c9 GAINS VS D\u00c9PENSES
    const itemsInput = validation.data.items;
    const names = itemsInput.map(i => i.id);

    const [ { data: dbArticles }, { data: dbOffers } ] = await Promise.all([
      supabase.schema('private').from('articles').select('*').in('name', names),
      supabase.schema('private').from('offers').select('*').in('title', names)
    ]);

    let pointsGagnes = 0;
    let coutTotalOffres = 0;
    let totalEuros = 0;
    const cleanItems = [];

    for (const item of itemsInput) {
      const art = dbArticles?.find(a => a.name === item.id);
      const off = dbOffers?.find(o => o.title === item.id);

      if (art) {
        pointsGagnes += (art.points || 0) * item.qty;
        totalEuros += (Number(art.price) || 0) * item.qty;
        cleanItems.push({ id: art.name, qty: item.qty, type: art.is_ecogeste ? 'ecogeste' : 'article' });
      } else if (off) {
        const coutUnitaire = Math.abs(off.points || 0);
        coutTotalOffres += coutUnitaire * item.qty;
        cleanItems.push({ id: off.title, qty: item.qty, type: 'offer' });
      } else {
        throw new Error(`Element inconnu dans le catalogue : ${item.id}`);
      }
    }

    // 6. LE VERROU DE S\u00c9CURIT\u00c9 SOLDE
    if (coutTotalOffres > soldeInitial) {
      console.log(`\u274c [BLOCKED] Solde insuffisant : Requis ${coutTotalOffres}, Dispo ${soldeInitial}`);
      return new Response(JSON.stringify({ 
        error: "Solde insuffisant pour ces recompenses.", 
        message: "Vous devez posseder les points avant de pouvoir les depenser." 
      }), { status: 400, headers: corsHeaders });
    }

    // 7. CR\u00c9ATION DE LA TRANSACTION
    const netPoints = pointsGagnes - coutTotalOffres;
    const { data: newTx, error: txError } = await supabase.schema('postgre_rpc').rpc('rpc_create_transaction', {
      p_user_id: user.id,
      p_restaurant_name: null,
      p_total: totalEuros,
      p_items: cleanItems,
      p_points: netPoints
    });

    if (txError || !newTx?.[0]) throw new Error("Erreur SQL lors de l'insertion");

    // 8. SIGNATURE ET R\u00c9PONSE
    const expiresAt = new Date(Date.now() + TRANSACTION_EXPIRY_MS).toISOString();
    const signature = await generateSignature(newTx[0].id, user.id, expiresAt);
    
    console.log(`\u2705 [SUCCESS] Transaction creee : ${newTx[0].id} par ${user.email} (${userData.role})`);

    return new Response(JSON.stringify({ qr: signature }), { 
      status: 200, 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
    });

  } catch (err: any) {
    console.error(`\ud83d\udd25 [FATAL] ${err.message}`);
    return new Response(JSON.stringify({ error: err.message }), { status: 400, headers: getCorsHeaders(req.headers.get("Origin")) });
  }
});