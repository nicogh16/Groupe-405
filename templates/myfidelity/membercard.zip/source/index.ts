import { createClient } from '@supabase/supabase-js';
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

// --- 🛡️ CONFIGURATION CORS DYNAMIQUE ---
const ALLOWED_ORIGINS = [
  "https://myfidelity.ca",
  "https://www.myfidelity.ca"
];

const getCorsHeaders = (origin: string | null) => {
  const headerOrigin = origin && ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': headerOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Content-Security-Policy': "default-src 'none'; img-src data: https:; style-src 'unsafe-inline'; frame-ancestors 'none';",
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'strict-origin-when-cross-origin'
  };
};

const BUCKET_NAME = 'member-card';
const DEFAULT_IMAGE = 'member-card.png';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const SUPABASE_ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY')!;
const CARD_SECRET_KEY = Deno.env.get('CARD_SECRET_KEY');

const supabaseAdmin = (SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY) 
  ? createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { 
      db: { schema: 'postgre_rpc' },
      auth: { persistSession: false } 
    })
  : null;

// --- 🛡️ RATE LIMITING UPSTASH (5 req/min par user) ---
const redis = new Redis({
  url: Deno.env.get('UPSTASH_REDIS_REST_URL')!,
  token: Deno.env.get('UPSTASH_REDIS_REST_TOKEN')!,
});

const ratelimit = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(5, '60 s'),
  prefix: 'rl:membercard',
});

function escapeXml(unsafe: string): string {
  return unsafe.replace(/[<>&'"]/g, (c) => {
    switch (c) {
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '&': return '&amp;';
      case '\'': return '&apos;';
      case '"': return '&quot;';
      default: return c;
    }
  });
}

Deno.serve(async (req) => {
  const origin = req.headers.get("Origin");
  const corsHeaders = getCorsHeaders(origin);

  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    if (!supabaseAdmin || !SUPABASE_ANON_KEY || !CARD_SECRET_KEY) {
      console.error('Secrets manquants');
      return new Response(JSON.stringify({ error: 'Erreur config' }), { status: 500, headers: corsHeaders });
    }

    if (req.method !== 'GET') {
      return new Response(JSON.stringify({ error: 'Methode non autorisee' }), { 
        status: 405, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) return new Response(JSON.stringify({ error: 'Token manquant' }), { status: 401, headers: corsHeaders });

    const supabaseAuth = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, { 
        global: { headers: { Authorization: authHeader } } 
    });
    const { data: { user }, error: userError } = await supabaseAuth.auth.getUser();

    if (userError || !user) return new Response(JSON.stringify({ error: 'Session invalide' }), { status: 401, headers: corsHeaders });

    // Rate limiting par userId (5 req/min)
    const { success, limit, remaining, reset } = await ratelimit.limit(user.id);
    if (!success) {
      return new Response(JSON.stringify({ error: 'Rate limit exceeded' }), {
        status: 429,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
          'X-RateLimit-Limit': limit.toString(),
          'X-RateLimit-Remaining': remaining.toString(),
          'X-RateLimit-Reset': reset.toString(),
        },
      });
    }

    const { data: userData, error: rpcError } = await supabaseAdmin
      .rpc('get_user', { p_user_id: user.id })
      .single();

    if (rpcError || !userData) {
      console.error(`Profil introuvable: ${user.id}`);
      return new Response(JSON.stringify({ error: 'Profil introuvable' }), { status: 404, headers: corsHeaders });
    }

    const rawName = userData.name?.trim() || userData.email?.split('@')[0] || 'Membre';
    const safeFullName = escapeXml(rawName);
    const imageUrl = `${SUPABASE_URL}/storage/v1/object/public/${BUCKET_NAME}/${DEFAULT_IMAGE}`;

    const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="500" height="300" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 300">
  <image href="${imageUrl}" width="500" height="300" preserveAspectRatio="xMidYMid slice"/>
  <text 
    x="30" 
    y="145" 
    fill="#ff7a00" 
    font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" 
    font-size="28" 
    font-weight="bold"
  >${safeFullName}</text>
</svg>`;

    return new Response(svg, {
      status: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'image/svg+xml',
        'Cache-Control': 'private, max-age=3600',
        'Content-Disposition': 'inline; filename="member-card.svg"'
      }
    });

  } catch (error: any) {
    console.error('Erreur:', error);
    return new Response(JSON.stringify({ error: 'Erreur interne' }), { 
      status: 500, 
      headers: getCorsHeaders(req.headers.get("Origin")) 
    });
  }
});