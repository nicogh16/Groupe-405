import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { Webhook } from 'https://esm.sh/standardwebhooks@1.0.0';
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

// --- 🛡️ CONFIGURATION CORS DYNAMIQUE ---
const ALLOWED_ORIGINS = [
  "https://myfidelity.ca",
  "https://www.myfidelity.ca",
  "http://localhost:5173"
];

const getCorsHeaders = (origin: string | null) => {
  const headerOrigin = origin && ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': headerOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json',
  };
};

const allowedDomains = [];

// --- 🛡️ RATE LIMITING UPSTASH GLOBAL (70 req/min pour toute la fonction) ---
const redis = new Redis({
  url: Deno.env.get('UPSTASH_REDIS_REST_URL')!,
  token: Deno.env.get('UPSTASH_REDIS_REST_TOKEN')!,
});

const ratelimit = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(70, '60 s'),
  prefix: 'rl:notify-new-user',
});

serve(async (req) => {
  const origin = req.headers.get("Origin");
  const corsHeaders = getCorsHeaders(origin);

  // Gestion du Preflight
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  // 🛡️ RATE LIMITING GLOBAL (70 req/min toutes sources confondues)
  const { success: rlOk } = await ratelimit.limit('global');
  if (!rlOk) {
    console.log(`⛔ [RATE LIMIT] Limite globale atteinte pour notify-new-user`);
    return new Response(JSON.stringify({ error: 'Rate limit exceeded' }), { status: 429, headers: corsHeaders });
  }

  const payload = await req.text();
  // Nettoyage du secret pour la librairie de vérification
  const secret = Deno.env.get('WEBHOOK_SECRET')?.replace('v1,whsec_', '');
  const headers = Object.fromEntries(req.headers);
  
  if (!secret) {
    console.error("WEBHOOK_SECRET manquant");
    return new Response(JSON.stringify({ error: "Server configuration error" }), { status: 500, headers: corsHeaders });
  }

  // 🛡️ SÉCURITÉ : Vérification de la signature HMAC
  const wh = new Webhook(secret);
  let verifiedPayload;

  try {
    verifiedPayload = wh.verify(payload, headers);
  } catch (error) {
    console.error("Signature verification failed");
    return new Response(JSON.stringify({ error: "Invalid signature" }), { status: 401, headers: corsHeaders });
  }

  try {
    const { user } = verifiedPayload;
    const email = user?.email || '';
    const domain = email.split('@')[1] || '';
    const name = user?.raw_user_meta_data?.name ?? "Nouvel utilisateur";

    // Filtrage par domaine
    if (allowedDomains.length > 0 && !allowedDomains.includes(domain)) {
      return new Response(
        JSON.stringify({ error: { message: 'Domaine non autorisé.', http_code: 400 } }),
        { status: 400, headers: corsHeaders }
      );
    }

    // 📧 ENVOI BREVO
    const BREVO_API_KEY = Deno.env.get("BREVO_API_KEY");
    if (BREVO_API_KEY) {
      const res = await fetch("https://api.brevo.com/v3/smtp/email", {
        method: "POST",
        headers: {
          "accept": "application/json",
          "content-type": "application/json",
          "api-key": BREVO_API_KEY
        },
        body: JSON.stringify({
          sender: { name: "ASAP Fidélité", email: "noreply@myfidelity.ca" },
          to: [{ email: "marketing@asap.polymtl.ca" }],
          subject: "🆕 Nouvelle inscription sur ASAP Fidélité",
          htmlContent: `<p><b>${name}</b> (${email}) vient de s'inscrire.</p>`
        })
      });

      if (res.ok) {
        console.log(`Email envoyé avec succès pour : ${email}`);
      } else {
        console.error("Erreur lors de l'appel à l'API Brevo");
      }
    }

    return new Response('{}', { status: 200, headers: corsHeaders });

  } catch (error: any) {
    console.error("Erreur interne :", error.message);
    return new Response(JSON.stringify({ error: { message: error.message } }), { 
      status: 400, 
      headers: getCorsHeaders(origin) 
    });
  }
});