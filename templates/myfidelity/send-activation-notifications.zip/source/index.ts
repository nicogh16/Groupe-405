import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.44.4';
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

// --- 🛡️ CONFIGURATION CORS DYNAMIQUE ---
const ALLOWED_ORIGINS = [
  "https://myfidelity.ca",
  "https://www.myfidelity.ca",
  "http://localhost:5173"
];

const getCorsHeaders = (origin: string | null) => {
  const headerOrigin = origin && ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': headerOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json',
  };
};

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// --- 🛡️ RATE LIMITING UPSTASH GLOBAL (3 req/min) ---
const redis = new Redis({
  url: Deno.env.get('UPSTASH_REDIS_REST_URL')!,
  token: Deno.env.get('UPSTASH_REDIS_REST_TOKEN')!,
});

const ratelimit = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(3, '60 s'),
  prefix: 'rl:send-activation-notifications',
});

interface ActivationResult {
  entityType: 'promotion' | 'poll';
  entityId: string;
  title: string;
  body: string;
  sent: number;
  error?: string;
}

Deno.serve(async (req) => {
  const origin = req.headers.get("Origin");
  const corsHeaders = getCorsHeaders(origin);

  // Gestion du Preflight (CORS)
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  // 🛡️ RATE LIMITING GLOBAL (3 req/min toutes sources confondues)
  const { success: rlOk } = await ratelimit.limit('global');
  if (!rlOk) {
    console.log(`\u26d4 [RATE LIMIT] Limite globale atteinte pour send-activation-notifications`);
    return new Response(JSON.stringify({ error: 'Rate limit exceeded' }), { status: 429, headers: corsHeaders });
  }

  const results: ActivationResult[] = [];
  let promotionsProcessed = 0;
  let pollsProcessed = 0;
  let totalSent = 0;

  try {
    const body = await req.json().catch(() => ({}));
    const directEntityType = (body as any)?.entity_type;
    const directEntityId = (body as any)?.entity_id;
    const directTitle = (body as any)?.title;
    const directBody = (body as any)?.body;

    // --- APPEL DIRECT DEPUIS TRIGGER ---
    if (directEntityType && directEntityId) {
      console.log(`[send-activation-notifications] Direct call: ${directEntityType} ${directEntityId}`);
      
      const category = directEntityType === 'promotion' ? 'promotions' : 'sondages';
      const { sent, error } = await sendActivationNotificationDirect(
        directEntityType as 'promotion' | 'poll',
        directEntityId,
        category,
        directTitle || 'Nouvelle notification',
        directBody || 'Une nouvelle notification est disponible.'
      );
      
      if (sent > 0 && !error) {
        await supabase.rpc('mark_notification_sent', {
          p_entity_type: directEntityType,
          p_entity_id: directEntityId,
        });
      }
      
      return new Response(
        JSON.stringify({ ok: true, directCall: true, entityType: directEntityType, entityId: directEntityId, sent, error }),
        { headers: corsHeaders, status: 200 }
      );
    }

    // --- TRAITEMENT NORMAL (CRON) ---
    const { data: settings } = await supabase
      .from('notification_action_settings')
      .select('action_id, enabled')
      .in('action_id', ['promotions', 'sondages']);

    const enabled = new Map<string, boolean>();
    for (const s of settings || []) {
      enabled.set(s.action_id, s.enabled !== false);
    }

    // 1. Traitement des Promotions
    if (enabled.get('promotions') !== false) {
      const { data: promotions } = await supabase.rpc('get_pending_promotion_activations');
      if (promotions && promotions.length > 0) {
        const processedPromotionIds: string[] = [];
        for (const p of promotions) {
          const title = (p as any).config_title?.trim() || p.title || 'Nouvelle promotion';
          const bodyTxt = ((p as any).config_body?.trim() || p.description || p.title || 'Une promotion est active.').slice(0, 200);
          const { sent, error } = await sendActivationNotification('promotion', p.id, 'promotions', title, bodyTxt);
          
          results.push({ entityType: 'promotion', entityId: p.id, title: p.title || 'Promotion', body: p.description || '', sent, error });
          promotionsProcessed++;
          totalSent += sent;

          if (sent > 0 && !error) processedPromotionIds.push(String(p.id));
        }
        
        if (processedPromotionIds.length > 0) {
          await supabase.rpc('update_promotions_notif_sent', { p_ids: processedPromotionIds });
        }
      }
    }

    // 2. Traitement des Sondages
    if (enabled.get('sondages') !== false) {
      const { data: polls } = await supabase.rpc('get_pending_poll_activations');
      if (polls && polls.length > 0) {
        const processedPollIds: string[] = [];
        for (const poll of polls) {
          const title = (poll as any).config_title?.trim() || poll.title || poll.question || 'Nouveau sondage';
          const bodyTxt = ((poll as any).config_body?.trim() || poll.description || `${title} est en ligne.`).slice(0, 200);
          const { sent, error } = await sendActivationNotification('poll', poll.id, 'sondages', title, bodyTxt);
          
          results.push({ entityType: 'poll', entityId: poll.id, title, body: poll.description || '', sent, error });
          pollsProcessed++;
          totalSent += sent;

          if (sent > 0 && !error) processedPollIds.push(String(poll.id));
        }

        if (processedPollIds.length > 0) {
          await supabase.rpc('update_polls_notif_sent', { p_ids: processedPollIds });
        }
      }
    }

    return new Response(
      JSON.stringify({ ok: true, promotionsProcessed, pollsProcessed, totalSent, details: results }),
      { headers: corsHeaders, status: 200 }
    );

  } catch (error) {
    console.error('[send-activation-notifications] Fatal error:', error);
    return new Response(
      JSON.stringify({ ok: false, error: String(error) }),
      { headers: getCorsHeaders(origin), status: 500 }
    );
  }
});

// --- HELPER FUNCTIONS ---

async function sendActivationNotification(
  entityType: 'promotion' | 'poll',
  entityId: string,
  category: 'promotions' | 'sondages',
  title: string,
  body: string
): Promise<{ sent: number; error?: string }> {
  try {
    const { data: tokensData, error: tokensError } = await supabase.rpc('get_notification_tokens_for_category', { p_category: category });
    if (tokensError) return { sent: 0, error: tokensError.message };

    const tokens: string[] = (tokensData as any[])?.map((r) => r?.notification_token).filter(Boolean) || [];
    if (tokens.length === 0) return { sent: 0 };

    const dataPayload = entityType === 'promotion' ? { promotionId: entityId } : { pollId: entityId };
    const messages = tokens.map((token) => ({
      to: token, sound: 'default', title, body, data: dataPayload, priority: 'high', channelId: 'default',
    }));

    const expoResponse = await fetch('https://exp.host/--/api/v2/push/send', {
      method: 'POST', headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify(messages),
    });

    if (!expoResponse.ok) return { sent: 0, error: `Expo API Error: ${expoResponse.status}` };

    const expoResult = await expoResponse.json();
    const data = expoResult.data || expoResult;
    const sent = Array.isArray(data) ? data.filter((r: any) => r.status === 'ok').length : 0;

    return { sent };
  } catch (e) {
    return { sent: 0, error: String(e) };
  }
}

async function sendActivationNotificationDirect(
  entityType: 'promotion' | 'poll',
  entityId: string,
  category: 'promotions' | 'sondages',
  title: string,
  body: string
): Promise<{ sent: number; error?: string }> {
  return await sendActivationNotification(entityType, entityId, category, title, body);
}