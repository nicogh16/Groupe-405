import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

// --- 🛡️ CONFIGURATION CORS DYNAMIQUE ---
const ALLOWED_ORIGINS = [
  "https://myfidelity.ca",
  "https://www.myfidelity.ca",
  "http://localhost:5173"
];

const getCorsHeaders = (origin: string | null) => {
  const headerOrigin = origin && ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': headerOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };
};

const RequestSchema = z.object({
  message: z.string().trim().min(1).max(500),
}).strict();

// --- 🛡️ RATE LIMITING UPSTASH (4 req/min par user) ---
const redis = new Redis({
  url: Deno.env.get('UPSTASH_REDIS_REST_URL')!,
  token: Deno.env.get('UPSTASH_REDIS_REST_TOKEN')!,
});

const ratelimit = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(4, '60 s'),
  prefix: 'rl:send-email',
});

serve(async (req) => {
  console.log('[LOG] === REQUEST START ===');
  console.log('[LOG] Method:', req.method);
  console.log('[LOG] URL:', req.url);
  
  const origin = req.headers.get("Origin");
  const corsHeaders = getCorsHeaders(origin);

  // Gestion du Preflight (CORS)
  if (req.method === 'OPTIONS') {
    console.log('[LOG] OPTIONS request, returning 204');
    return new Response(null, { headers: corsHeaders, status: 204 });
  }

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY')!;
    const BREVO_API_KEY = Deno.env.get("BREVO_API_KEY");
    console.log('[LOG] Environment variables loaded');

    // 1. AUTHENTIFICATION (JWT obligatoire)
    const authHeader = req.headers.get('Authorization');
    console.log('[LOG] Auth header present:', !!authHeader);
    if (!authHeader) {
      console.log('[LOG] ERROR: No auth header, returning 401');
      return new Response(JSON.stringify({ error: '401' }), { status: 401, headers: corsHeaders });
    }

    const supabaseUser = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: authError } = await supabaseUser.auth.getUser();
    console.log('[LOG] Auth result - User email:', user?.email || 'null');
    console.log('[LOG] Auth result - Error:', authError?.message || 'none');
    if (authError || !user) {
      console.log('[LOG] ERROR: Auth failed, returning 401');
      return new Response(JSON.stringify({ error: '401' }), { status: 401, headers: corsHeaders });
    }

    // 🛡️ RATE LIMITING (4 req/min par user)
    const { success: rlOk } = await ratelimit.limit(user.id);
    console.log('[LOG] Rate limit check:', rlOk ? 'PASSED' : 'BLOCKED');
    if (!rlOk) {
      console.log(`🚫 [RATE LIMIT] ${user.email} bloqué sur send-email`);
      return new Response(JSON.stringify({ error: '429' }), { status: 429, headers: corsHeaders });
    }

    // 2. VALIDATION
    const bodyRaw = await req.json().catch(() => ({}));
    console.log('[LOG] Request body raw:', JSON.stringify(bodyRaw));
    const validation = RequestSchema.safeParse(bodyRaw);
    console.log('[LOG] Validation success:', validation.success);
    if (!validation.success) {
      console.log('[LOG] ERROR: Validation failed');
      console.log('[LOG] Validation errors:', JSON.stringify(validation.error));
      return new Response(JSON.stringify({ error: '400' }), { status: 400, headers: corsHeaders });
    }

    console.log('[LOG] Validated message length:', validation.data.message.length);
    console.log('[LOG] Validated message preview:', validation.data.message.substring(0, 100));

    // 3. ENVOI BREVO
    const userFullName = user.user_metadata?.full_name || user.user_metadata?.name || 'Utilisateur';
    console.log('[LOG] User full name:', userFullName);
    console.log('[LOG] User email:', user.email);
    
    // Diviser le message par les doubles sauts de ligne et créer un paragraphe pour chaque section
    const sections = validation.data.message.split('\n\n').filter(s => s.trim().length > 0);
    const messageHtml = sections.map(section => `<p>${section.trim().replace(/\n/g, '<br>')}</p>`).join('');
    
    const brevoPayload = {
      sender: { name: "ASAP Fidélité", email: "noreply@myfidelity.ca" }, 
      to: [{ email: "marketing@asap.polymtl.ca" }],
      subject: "Demande d'activation Carte : " + userFullName,
      htmlContent: messageHtml
    };
    
    console.log('[LOG] Brevo payload prepared');
    console.log('[LOG] Sending to Brevo API...');
    
    const brevoRes = await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: {
        "accept": "application/json",
        "content-type": "application/json",
        "api-key": BREVO_API_KEY!
      },
      body: JSON.stringify(brevoPayload)
    });

    const result = await brevoRes.json();
    console.log('[LOG] Brevo response status:', brevoRes.status);
    console.log('[LOG] Brevo response:', JSON.stringify(result));

    if (!brevoRes.ok) {
      console.error("[LOG] ERROR: Brevo API failed");
      console.error("Erreur Brevo détaillée:", JSON.stringify(result));
      throw new Error("Email service failed");
    }

    console.log('[LOG] === SUCCESS === Email sent successfully');
    return new Response(JSON.stringify({ success: true }), { 
      status: 200, 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
    });

  } catch (error: any) {
    console.error('[LOG] === FATAL ERROR ===');
    console.error(`[Fatal Error]: ${error.message}`);
    console.error(`[Fatal Error Stack]:`, error.stack);
    return new Response(JSON.stringify({ error: '500' }), { 
      status: 500, 
      headers: { ...getCorsHeaders(origin), 'Content-Type': 'application/json' } 
    });
  }
});