/**
 * Edge Function Supabase : envoi email de bienvenue membre ASaP
 * Secrets (npx supabase secrets set) : BREVO_API_KEY ou RESEND_API_KEY
 * Optionnel : EMAIL_FROM (ex: "ASaP Fidélité <noreply@myfidelity.ca>")
 */

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const getHtml = (displayName: string) => `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:Arial,sans-serif;line-height:1.6;color:#333;max-width:600px;margin:0 auto;padding:20px">
<h1 style="color:#ea580c;font-size:24px">Félicitations ${displayName} !</h1>
<p>Vous faites désormais partie des <strong>membres ASaP</strong> de notre programme de fidélité.</p>
<p>En tant que membre, vous bénéficiez d'avantages exclusifs et pouvez accumuler des points sur vos achats.</p>
<p>Connectez-vous à l'application ASaP pour découvrir tous vos avantages.</p>
<p style="margin-top:32px">À bientôt,<br><strong>L'équipe ASaP Fidélité</strong></p>
</body></html>`

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { email, name } = await req.json() as { email: string; name?: string }
    if (!email?.trim()) {
      return new Response(
        JSON.stringify({ error: 'email requis' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const displayName = name?.trim() || email.split('@')[0] || 'Membre'
    const fromEnv = Deno.env.get('EMAIL_FROM') || ''
    const senderMatch = fromEnv.match(/^(.+?)\s*<([^>]+)>$/)
    const senderName = senderMatch ? senderMatch[1].trim() : 'ASaP Fidélité'
    // IMPORTANT: L'expéditeur doit être vérifié dans Brevo (Paramètres > Expéditeurs)
    const senderEmail = senderMatch ? senderMatch[2].trim() : (Deno.env.get('BREVO_SENDER_EMAIL')?.trim() || 'noreply@myfidelity.ca')
    const html = getHtml(displayName)

    // Priorité 1 : Brevo API
    const brevoKey = Deno.env.get('BREVO_API_KEY')?.trim()
    if (brevoKey) {
      const payload = {
        sender: { name: senderName, email: senderEmail },
        to: [{ email, name: displayName }],
        subject: 'Bienvenue parmi les membres ASaP !',
        htmlContent: html,
      }
      console.log('[send-member-welcome-email] Envoi Brevo vers', email, 'depuis', senderEmail)
      const res = await fetch('https://api.brevo.com/v3/smtp/email', {
        method: 'POST',
        headers: { 'api-key': brevoKey, 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const resBody = await res.text()
      if (!res.ok) {
        console.error('[send-member-welcome-email] Brevo erreur:', res.status, resBody)
        return new Response(JSON.stringify({ error: 'Erreur Brevo', details: resBody }), {
          status: 502,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        })
      }
      let messageId = ''
      try {
        const parsed = JSON.parse(resBody)
        messageId = parsed?.messageId || ''
      } catch (_) {}
      console.log('[send-member-welcome-email] Brevo OK messageId=', messageId)
      return new Response(JSON.stringify({ success: true, messageId }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // Priorité 2 : Resend API
    const resendKey = Deno.env.get('RESEND_API_KEY')?.trim()
    if (resendKey) {
      const fromResend = fromEnv || `${senderName} <${senderEmail}>`
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${resendKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from: fromResend,
          to: [email],
          subject: 'Bienvenue parmi les membres ASaP !',
          html,
        }),
      })
      if (!res.ok) {
        const err = await res.text()
        console.error('[send-member-welcome-email] Resend:', res.status, err)
        return new Response(JSON.stringify({ error: 'Erreur Resend', details: err }), {
          status: 502,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        })
      }
      return new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    console.warn('[send-member-welcome-email] Aucun secret (BREVO_API_KEY ou RESEND_API_KEY)')
    return new Response(JSON.stringify({ error: 'Secrets non configurés' }), {
      status: 503,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (e) {
    console.error('[send-member-welcome-email]', e)
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
