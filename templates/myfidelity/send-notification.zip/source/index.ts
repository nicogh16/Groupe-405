import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

// --- 🛡️ CONFIGURATION CORS DYNAMIQUE ---
const ALLOWED_ORIGINS = [
  "https://myfidelity.ca",
  "https://www.myfidelity.ca",
  "http://localhost:5173",
  "http://localhost:5174"
];

const getCorsHeaders = (origin: string | null) => {
  const headerOrigin = origin && ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': headerOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };
};

const PushSchema = z.object({
  title: z.string().min(1).max(100),
  body: z.string().min(1).max(500),
  target: z.object({
    type: z.enum(['token', 'tokens', 'email', 'role']),
    value: z.union([z.string().min(1), z.array(z.string().min(1))])
  }),
  data: z.record(z.any()).optional(),
}).strict();

// --- 🛡️ RATE LIMITING UPSTASH GLOBAL (10 req/min) ---
const redis = new Redis({
  url: Deno.env.get('UPSTASH_REDIS_REST_URL')!,
  token: Deno.env.get('UPSTASH_REDIS_REST_TOKEN')!,
});

const ratelimit = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(10, '60 s'),
  prefix: 'rl:send-notification',
});

serve(async (req) => {
  const origin = req.headers.get("Origin");
  const corsHeaders = getCorsHeaders(origin);

  // Gestion du Preflight (CORS)
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  // 🛡️ RATE LIMITING GLOBAL (10 req/min toutes sources confondues)
  const { success: rlOk } = await ratelimit.limit('global');
  if (!rlOk) {
    console.log(`\u26d4 [RATE LIMIT] Limite globale atteinte pour send-notification`);
    return new Response(JSON.stringify({ error: 'Rate limit exceeded' }), { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SERVICE_ROLE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    // 1. 🛡️ AUTHENTIFICATION
    const authHeader = req.headers.get('Authorization');
    const apikeyHeader = req.headers.get('apikey');
    
    if (!authHeader && !apikeyHeader) {
      return new Response(JSON.stringify({ error: '401', message: 'No auth header' }), { status: 401, headers: corsHeaders });
    }

    // Extraction propre du Bearer token
    const getBearerToken = (header: string | null) => {
      if (!header) return null;
      const parts = header.split(' ');
      return parts.length === 2 ? parts[1].trim() : parts[0].trim();
    };

    const tokenFromAuth = getBearerToken(authHeader);
    const tokenFromApikey = apikeyHeader?.trim() || null;

    // Service role : correspondance exacte OU token au format nouvelle API (sb_secret_)
    const isNewApiKeyFormat = (t: string | null) => t != null && t.startsWith('sb_secret_') && t.length >= 30;
    const isServiceRole =
      (tokenFromAuth === SERVICE_ROLE) ||
      (tokenFromApikey === SERVICE_ROLE) ||
      isNewApiKeyFormat(tokenFromAuth) ||
      isNewApiKeyFormat(tokenFromApikey);

    console.log('[AUTH DEBUG]', {
      tokenFromAuthPrefix: tokenFromAuth?.substring(0, 20),
      serviceRolePrefix: SERVICE_ROLE?.substring(0, 20),
      exactMatch: tokenFromAuth === SERVICE_ROLE,
      isNewFormatAuth: isNewApiKeyFormat(tokenFromAuth),
      isServiceRole,
    });

    if (!isServiceRole) {
      // Authentification utilisateur via JWT
      const supabaseAdmin = createClient(SUPABASE_URL, SERVICE_ROLE, {
        db: { schema: 'private' }
      });

      const supabaseUser = createClient(SUPABASE_URL, Deno.env.get('SUPABASE_ANON_KEY')!, {
        global: { headers: { Authorization: authHeader } }
      });
      
      const { data: { user }, error: authError } = await supabaseUser.auth.getUser();
      if (authError || !user) {
        return new Response(JSON.stringify({
          code: 401,
          message: 'Invalid JWT or service role key required',
        }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }

      // 2. 🛡️ VÉRIFICATION DU RÔLE (ADMIN SEULEMENT)
      const { data: dbUser, error: roleError } = await supabaseAdmin
        .from('users')
        .select('role')
        .eq('id', user.id)
        .single();

      if (roleError || dbUser?.role !== 'administrateur') {
        console.warn(`Acc\u00e8s refus\u00e9 : L'utilisateur ${user.email} n'est pas administrateur.`);
        return new Response(JSON.stringify({ error: '403', message: 'Acc\u00e8s r\u00e9serv\u00e9 aux administrateurs' }), { 
          status: 403, 
          headers: corsHeaders 
        });
      }
      
      console.log(`[USER AUTH]: Push envoy\u00e9 par ${user.email}`);
    } else {
      console.log(`[SERVICE ROLE AUTH]: Appel depuis le serveur tRPC avec service role key`);
    }

    // 3. 🛡️ VALIDATION DES DONNÉES
    const bodyRaw = await req.json().catch(() => ({}));
    const validation = PushSchema.safeParse(bodyRaw);
    if (!validation.success) {
      return new Response(JSON.stringify({ error: '400', details: validation.error.format() }), { status: 400, headers: corsHeaders });
    }

    const { title, body: messageBody, target, data } = validation.data;

    // 4. RÉCUPÉRATION DES TOKENS
    let tokens: string[] = [];

    if (target.type === 'token') {
      tokens = [target.value as string];
    } else if (target.type === 'tokens') {
      tokens = target.value as string[];
    } else {
      const rpcClient = createClient(SUPABASE_URL, SERVICE_ROLE, { db: { schema: 'public' } });
      const rpcParam = target.type === 'email' ? { p_email: target.value } : { p_role: target.value as string };
      const { data: rpcData, error } = await rpcClient.rpc('get_notification_tokens', rpcParam);
      if (error) throw error;
      tokens = rpcData?.map((t: any) => t.notification_token) || [];
    }

    if (!tokens.length) return new Response(JSON.stringify({ error: '404', message: 'No tokens found' }), { status: 404, headers: corsHeaders });

    // 5. ENVOI EXPO (avec chunking pour respecter la limite de 100 notifications par requ\u00eate)
    const EXPO_CHUNK_SIZE = 100;
    const chunks: string[][] = [];
    
    for (let i = 0; i < tokens.length; i += EXPO_CHUNK_SIZE) {
      chunks.push(tokens.slice(i, i + EXPO_CHUNK_SIZE));
    }
    
    console.log(`[EXPO]: Envoi de ${tokens.length} notifications en ${chunks.length} chunk(s)`);
    
    let totalSent = 0;
    let failedChunks = 0;
    const allResults: any[] = [];
    
    for (let i = 0; i < chunks.length; i++) {
      const chunk = chunks[i];
      const messages = chunk.map(token => ({
        to: token,
        sound: 'default',
        title,
        body: messageBody,
        data: data || {},
        priority: 'high',
        channelId: 'default'
      }));

      try {
        const expoRes = await fetch('https://exp.host/--/api/v2/push/send', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(messages)
        });

        if (!expoRes.ok) {
          console.error(`[EXPO ERROR]: Chunk ${i + 1}/${chunks.length} failed with status ${expoRes.status}`);
          failedChunks++;
          continue;
        }

        const result = await expoRes.json();
        allResults.push(...(Array.isArray(result.data) ? result.data : [result]));
        totalSent += chunk.length;
      } catch (error: any) {
        console.error(`[EXPO ERROR]: Chunk ${i + 1}/${chunks.length} exception:`, error.message);
        failedChunks++;
      }
    }
    
    const partialFailure = totalSent < tokens.length;
    const success = totalSent > 0;
    
    console.log(`[RESULT]: ${totalSent}/${tokens.length} notifications envoy\u00e9es (${failedChunks} chunk(s) \u00e9chou\u00e9(s))`);

    return new Response(JSON.stringify({ 
      success, 
      partialFailure,
      sentTo: totalSent, 
      totalTokens: tokens.length,
      failedTokens: tokens.length - totalSent,
      chunks: chunks.length,
      failedChunks,
      results: allResults 
    }), {
      status: success ? 200 : 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error(`[Fatal Error]: ${error.message}`);
    return new Response(JSON.stringify({ error: '500', message: error.message }), { 
      status: 500, 
      headers: getCorsHeaders(origin) 
    });
  }
});
