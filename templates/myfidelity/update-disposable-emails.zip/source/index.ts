import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

// --- 🛡️ CONFIGURATION CORS DYNAMIQUE ---
const ALLOWED_ORIGINS = [
  "https://myfidelity.ca",
  "https://www.myfidelity.ca"
];

const getCorsHeaders = (origin: string | null) => {
  const headerOrigin = origin && ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': headerOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json',
  };
};

// --- 🛡️ RATE LIMITING UPSTASH GLOBAL (4 req/min) ---
const redis = new Redis({
  url: Deno.env.get('UPSTASH_REDIS_REST_URL')!,
  token: Deno.env.get('UPSTASH_REDIS_REST_TOKEN')!,
});

const ratelimit = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(4, '60 s'),
  prefix: 'rl:update-disposable-emails',
});

Deno.serve(async (req) => {
  const origin = req.headers.get("Origin");
  const corsHeaders = getCorsHeaders(origin);

  // Gestion du Preflight (CORS)
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  // 🛡️ RATE LIMITING GLOBAL (4 req/min toutes sources confondues)
  const { success: rlOk } = await ratelimit.limit('global');
  if (!rlOk) {
    console.log(`\u26d4 [RATE LIMIT] Limite globale atteinte pour update-disposable-emails`);
    return new Response(JSON.stringify({ error: 'Rate limit exceeded' }), { status: 429, headers: corsHeaders });
  }

  // 1. 🛡️ SÉCURITÉ CRON : Vérifier que l'appel vient bien de l'interne (Supabase)
  const authHeader = req.headers.get('Authorization');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

  if (authHeader !== `Bearer ${serviceKey}`) {
    console.error("Tentative d'acc\u00e8s non autoris\u00e9e \u00e0 la fonction de nettoyage.");
    return new Response(
      JSON.stringify({ error: "Acc\u00e8s refus\u00e9 : ex\u00e9cution interne uniquement." }), 
      { status: 403, headers: corsHeaders }
    );
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    serviceKey ?? ''
  )

  const LIST_URL = "https://disposable.github.io/disposable-email-domains/domains.txt";

  try {
    console.log("D\u00e9marrage de la mise \u00e0 jour des domaines jetables...");
    const response = await fetch(LIST_URL);
    if (!response.ok) throw new Error("Impossible de t\u00e9l\u00e9charger la liste GitHub");
    
    const text = await response.text();
    const domains = text.split('\n')
      .map(d => d.trim().toLowerCase())
      .filter(d => d.includes('.') && d.length > 3);

    const CHUNK_SIZE = 1000;
    for (let i = 0; i < domains.length; i += CHUNK_SIZE) {
      const chunk = domains.slice(i, i + CHUNK_SIZE).map(d => ({ domain: d }));
      
      const { error } = await supabase
        .schema('private')
        .from('disposable_emails')
        .upsert(chunk, { onConflict: 'domain' });
      
      if (error) throw error;
    }

    console.log(`Succ\u00e8s : ${domains.length} domaines synchronis\u00e9s.`);
    return new Response(
      JSON.stringify({ success: true, count: domains.length }), 
      { status: 200, headers: corsHeaders }
    );
  } catch (err: any) {
    console.error(`Erreur Cron: ${err.message}`);
    return new Response(
      JSON.stringify({ error: err.message }), 
      { status: 500, headers: getCorsHeaders(origin) }
    );
  }
})