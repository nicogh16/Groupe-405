import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from '@supabase/supabase-js';
import * as djwt from 'https://deno.land/x/djwt@v2.9/mod.ts';
import { z } from 'https://deno.land/x/zod@v3.22.4/mod.ts';
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_ROLE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY')!;
const QR_SECRET = Deno.env.get('QR_SECRET')!;

// --- 🛡️ CONFIGURATION CORS DYNAMIQUE ---
const ALLOWED_ORIGINS = [
  "https://myfidelity.ca",
  "https://www.myfidelity.ca"
  ];

const getCorsHeaders = (origin: string | null) => {
  const headerOrigin = origin && ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': headerOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };
};

const ConfirmSchema = z.object({
  "signature": z.string().min(1),
  "restaurant-name": z.string().min(1)
}).strict();

// --- 🛡️ RATE LIMITING UPSTASH (70 req/min par user) ---
const redis = new Redis({
  url: Deno.env.get('UPSTASH_REDIS_REST_URL')!,
  token: Deno.env.get('UPSTASH_REDIS_REST_TOKEN')!,
});

const ratelimit = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(70, '60 s'),
  prefix: 'rl:validate-transaction',
});

serve(async (req) => {
  const origin = req.headers.get("Origin");
  const corsHeaders = getCorsHeaders(origin);

  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    // 1. 🛡️ AUTHENTIFICATION
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.log("\u274c [CANCEL] Tentative sans token (401)");
      return new Response(JSON.stringify({ error: '401' }), { status: 401, headers: corsHeaders });
    }

    const supabaseAdmin = createClient(SUPABASE_URL, SERVICE_ROLE, { db: { schema: 'private' } });
    const supabaseUser = createClient(SUPABASE_URL, ANON_KEY, { global: { headers: { Authorization: authHeader } } });

    const { data: { user: staff }, error: authError } = await supabaseUser.auth.getUser();
    if (authError || !staff) {
      console.log("\u274c [CANCEL] Token invalide ou expire (401)");
      return new Response(JSON.stringify({ error: '401' }), { status: 401, headers: corsHeaders });
    }

    // 🛡️ RATE LIMITING (70 req/min par user)
    const { success: rlOk } = await ratelimit.limit(staff.id);
    if (!rlOk) {
      console.log(`\u26d4 [RATE LIMIT] User ${staff.email} bloque`);
      return new Response(JSON.stringify({ error: 'Rate limit exceeded' }), { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // 2. 🛡️ VERIFICATION ROLE
    const { data: profile } = await supabaseAdmin.from('users').select('role').eq('id', staff.id).single();
    if (profile?.role !== 'caissier') {
      console.log(`\u274c [CANCEL] Acces refuse pour ${staff.email}. Role '${profile?.role}' insuffisant (403)`);
      return new Response(JSON.stringify({ error: '403', message: 'Reserve aux caissiers' }), { status: 403, headers: corsHeaders });
    }

    // 3. 🛡️ PARSING BODY
    const bodyRaw = await req.json().catch(() => ({}));
    const validation = ConfirmSchema.safeParse(bodyRaw);
    if (!validation.success) {
      console.log("\u274c [CANCEL] Format de requete invalide ou champs manquants (400)");
      return new Response(JSON.stringify({ error: '400' }), { status: 400, headers: corsHeaders });
    }

    const restaurantName = validation.data["restaurant-name"];
    const signature = validation.data["signature"];

    // 4. 🛡️ VERIFICATION RESTAURANT
    const { data: restoExists } = await supabaseAdmin
      .from('restaurants')
      .select('name')
      .eq('name', restaurantName)
      .maybeSingle();

    if (!restoExists) {
      console.log(`\u274c [CANCEL] Restaurant '${restaurantName}' inexistant (400)`);
      return new Response(JSON.stringify({ error: '400', message: 'Restaurant non valide' }), { status: 400, headers: corsHeaders });
    }

    // 5. 🛡️ VERIFICATION SIGNATURE QR
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(QR_SECRET), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
    let payload;
    try {
      payload = await djwt.verify(signature, key);
      console.log(`\u2705 [INFO] Signature QR valide pour l'utilisateur ${payload.user_id}`);
    } catch {
      console.log(`\u274c [CANCEL] Signature QR corrompue ou expiree pour ${restaurantName} (403)`);
      return new Response(JSON.stringify({ error: '403', message: 'Signature invalide' }), { status: 403, headers: corsHeaders });
    }

    // 6. 🛡️ CONFIRMATION SQL
    const rpcClient = createClient(SUPABASE_URL, SERVICE_ROLE, { db: { schema: 'postgre_rpc' } });
    const { data: confirmed, error: cError } = await rpcClient.rpc('rpc_confirm_transaction', {
      p_transaction_id: payload.transaction_id,
      p_restaurant_name: restaurantName
    });

    if (cError) {
      console.log(`\u274c [CANCEL] Echec SQL pour la transaction ${payload.transaction_id} : ${cError.message}`);
      throw new Error("Erreur DB confirmation");
    }

    // 7. SUCCES & REALTIME
    const result = confirmed?.[0];
    if (!result) throw new Error("Aucun resultat de confirmation");

    const userEmail = result.email;
    const userPoints = result.points_user;

    const realtimeClient = createClient(SUPABASE_URL, SERVICE_ROLE);
    const channel = realtimeClient.channel(`user-${userEmail}`);
    
    const { error: broadcastError } = await channel.send({
      type: 'broadcast',
      event: 'transaction-update',
      payload: { 
        status: 'valide', 
        points_user: userPoints, 
        restaurant_name: restaurantName 
      },
    });

    if (broadcastError) {
      console.log(`\u26a0\ufe0f [WARN] Erreur realtime broadcast: ${broadcastError.message}`);
    }

    return new Response(JSON.stringify({ success: true, message: "Transaction confirmee" }), { 
      status: 200, 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
    });

  } catch (err: any) {
    console.log(`\ud83d\udd25 [FATAL] Erreur interne : ${err.message}`);
    return new Response(JSON.stringify({ error: '500' }), { 
      status: 500, 
      headers: getCorsHeaders(origin) 
    });
  }
});